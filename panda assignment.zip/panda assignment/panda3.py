import pandas
df=pandas.read_csv("movies_metadata.csv",encoding='latin-1',on_bad_lines='skip')
print("number of rows=",len(df))
print("number of columns=",len(df.columns))