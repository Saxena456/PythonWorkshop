import pandas
df=pandas.read_csv("movies_metadata.csv",encoding='latin',on_bad_lines='skip')
print(df.columns)
