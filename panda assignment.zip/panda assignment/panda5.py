import pandas
df=pandas.read_csv("movies_metadata.csv",encoding='latin-1',on_bad_lines='skip')
print("longest runtime=",df['runtime'].max(),"and shortest runtime=",df['runtime'].min())
